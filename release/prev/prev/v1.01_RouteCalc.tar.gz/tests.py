
def test_singleton():
    from lib.utils import cache
    from lib.apis import googleapi

    __cache = cache.cache_instance_factory()
    __api = googleapi.api_instance_factory()

    __cache2 = cache.cache_instance_factory()
    __api2 = googleapi.api_instance_factory()

    return __cache == __cache2 and __api == __api2
    pass


def test_cache():
    from lib.utils import cache
    from lib.calc.place import Place
    cache = cache.cache_instance_factory()
    print(cache)
    place_a = Place(49.2441419, 31.4615571, name='Смела')
    place_b = Place(49.036468, 24.3423108, name='Калуш')
    distances = cache.fetch_cached_distance([place_a], [place_b])
    print(str(round(distances[0].distance/1000, 1)) + ' kilometers')
    pass

print('test_singleton_factory: '+str(test_singleton()))


test_cache()
