

# def compose_sms_v1(details):
#     s = list()
#
#     # "Черкассы - Смела - Калуш"
#     for place in details['route']:
#         s.append(place.name)
#         s.append(' - ')
#     s.pop()
#
#     # ": 755,2 км"
#     s.append(': ')
#     s.append(str(round(details['total_distance']/1000, 1)))
#     s.append(' км')
#     s.append('\n')
#
#     # Тент 10 (18,0 грн/км)
#     s.append(details['vehicle'])
#     s.append(' (')
#     s.append(str(details['price']))
#     s.append(' грн/км)')
#     s.append('\n')
#
#     # 13600,00 грн
#     s.append(str(details['rounded_cost'])+'0')
#     s.append(' грн')
#     s.append('\n')
#
#     # +380953459607 - Александр
#     s.append('+380953459607 - Александр\n')
#
#     # https://intersmartgroup.com
#     s.append('https://intersmartgroup.com')
#
#     return str().join(s)


def compose_sms(details):
    s = list()

    # "Смела - Калуш"
    s.append(f'{details["place_a"].name} - {details["place_b"].name}')

    # ": 755,2 км"
    s.append(': ')
    s.append(str(round(details['total_distance']/1000, 1)))
    s.append(' км')
    s.append('\n')

    # Тент 10
    s.append(details['vehicle'])
    s.append('\n')

    # 13600,00 грн
    s.append(str(details['rounded_cost'])+'0')
    s.append(' грн')
    s.append('\n')

    # +380953459607
    s.append('+380953459607\n\n')

    # https://intersmartgroup.com
    s.append('https://intersmartgroup.com/')

    return str().join(s)


def __generate_map_url(*args):
    if len(args) < 2:
        raise RuntimeError('Internal error 6')

    base = f'https://www.google.com.ua/maps/dir/'
    # appendix = f'{str(lat)},{str(lng)}/'
    s = list()
    s.append(base)

    for place in args:
        s.append(f'{str(place.lat)},{str(place.lng)}/')
    return str().join(s)


def __generate_place_chain(*args):

    if len(args) < 1:
        raise RuntimeError('Internal error 7')

    s = list()
    for place in args:
        s.append(place.name)
        s.append(' - ')
    s.pop()

    return str().join(s)


def compose_telegram(intent, details):
    s = list()

    # Просчет или Клиент нажал ПЕРЕЗВОНИТЬ
    if intent == 'calc':
        s.append('Просчет\n\n')
    elif intent == 'callback':
        s.append('Клиент нажал Перезвонить\n\n')
    else:
        raise RuntimeError('Internal Error 5')

    # Из: Репки, Черниговская область, Украина
    # В: Смела, Черкасская область, Украина
    # Маршрут: https://www.google.com.ua/maps/dir/50.5465397,30.4010721/50.5380305,30.4443308/50.554393,30.469565/
    s.append('Из: '+details["place_a"].name_long+'\n')
    s.append('В: '+details["place_b"].name_long+'\n')
    s.append(f'[Google Maps]({__generate_map_url(details["place_a"], details["place_b"])})\n\n')

    # Расчитанный маршрут: Чернигов - Репки - Смела - Черкассы
    # Расчитанное растояние: 985 км
    # [ссылка](https://)
    s.append(f'Расчитанный маршрут: {__generate_place_chain(*details["route"])}\n')
    s.append(f'Расчитанное растояние: {round(float(details["total_distance"])/1000, 0)} км\n')
    s.append(f'[Google Maps]({__generate_map_url(*details["route"])})\n\n')

    # Авто: Тент 10
    # Цена: 13600,00
    # Телефон клиента: 380672232586
    s.append(f'Авто: {details["vehicle"]}\n')
    s.append(f'Цена: {details["rounded_cost"]}0 грн ({details["price"]} грн/км)\n')
    s.append(f'Телефон клиента: +{details["client_phone"]}')

    return str().join(s)
